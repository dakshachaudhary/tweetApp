package com.tweetapp.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TweetConfigTest {

}
